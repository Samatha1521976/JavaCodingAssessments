package com.exception;
import java .util.*;

public class SampleExceptionDemo {

public int arrayAccessMeth(int arr[],int pos)throws ArrayIndexOutOfBoundsException
	{
		
		return (arr[pos]);
	}

	public static void main(String[] args) {
		SampleExceptionDemo demo=new SampleExceptionDemo();
		System.out.println("Enter  the No of elements in array");
int count=s.nextInt();
int arr[]=new int[count];
System.out.println("Enter "+count+" Array Elements");
for(int i=0;i<count;i++)
{
	arr[i]=s.nextInt();
	
}
System.out.println("enter position to access");
int pos=s.nextInt();
System.out.println(demo.arrayAccessMeth(arr,pos));
}




}
